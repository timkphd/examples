#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
main() {
 char name[128],fname[128];
 pid_t mypid;
 FILE *f;

gethostname(name, 128);
mypid=getpid();
sprintf(fname,"%s_%8.8d",name,(int)mypid);
f=fopen(fname,"w");
fprintf(f,"C says hello from %d on %s\n",(int)mypid,name);
}

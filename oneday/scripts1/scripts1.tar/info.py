#!/opt/development/python/2.6.5/bin/python
import os
name=os.uname()[1]
mypid=os.getpid()
fname="%s_%8.8d" % (name,mypid)
f=open(fname,"w")
f.write("Python says hello from %d on %s\n" %(mypid,name))

